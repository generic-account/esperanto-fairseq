***Esperanto Morphological Tokenizer***

lorem ipsum dolor sit amet or however this goes